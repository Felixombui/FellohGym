<?php
$server='localhost';
$username='root';
$password='kasarani';
$db='macrasys_gym';
$config=mysqli_connect($server,$username,$password,$db) or die('Connection Failed.');
?>